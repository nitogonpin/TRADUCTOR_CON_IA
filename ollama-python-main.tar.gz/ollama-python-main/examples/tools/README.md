# tools

This example demonstrates how to utilize tool calls with an asynchronous Ollama client and the chat endpoint. 
