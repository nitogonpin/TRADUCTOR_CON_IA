# pull-progress

This example emulates `ollama pull` using the Python library and [`tqdm`](https://tqdm.github.io/).

## Setup

```shell
pip install -r requirements.txt
```
